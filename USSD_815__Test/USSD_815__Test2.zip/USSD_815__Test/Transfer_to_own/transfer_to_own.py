def transfer_to_own_account(self):
        try:
            self.enter_pin_to_login()
            
            # Navigate to Transfer menu
            expected_home = [
                "1: My Accounts",
                "2: Transfer",
                "3: Transfer to Other Bank",
                "4: Transfer to Own",
                "5: Airtime",
                "6: Utilities",
                "7: Exchange Rates",
                "8: More options"
            ]
            
            if not self.send_ussd(expected_home, "4", "transfer_to_own_account"):
                self.update_status("Transfer", [42], "Fail", 7)  # T011 row
                return False

            # Step 1: Select debit account
            message = self.get_ussd_message()
            if "transfer to own" not in message.lower():
                self.update_status("Transfer", [42], "Fail", 7)
                return False
                
            # Get available accounts
            accounts = [line for line in message.split("\n") if "ETB" in line or "Dollar" in line]
            if not accounts:
                self.update_status("Transfer", [42], "Fail", 7)
                return False
                
            # Select first account as debit account
            debit_account_option = accounts[0].split(":")[0].strip()
            self.send_ussd_input(debit_account_option)
            
            # Step 2: Select credit account (should show other accounts)
            message = self.get_ussd_message()
            if "Funds Transfer Own Account" not in message:
                self.update_status("Transfer", [42], "Fail", 7)
                return False
                
            # Verify the debit account is not in the list
            accounts = [line for line in message.split("\n") if "ETB" in line or "Dollar" in line]
            if not accounts:
                self.update_status("Transfer", [42], "Fail", 7)
                return False
                
            # Select first available account as credit account
            credit_account_option = accounts[0].split(":")[0].strip()
            self.send_ussd_input(credit_account_option)
            
            # Step 3: Enter amount
            message = self.get_ussd_message()
            if "Request Debit" not in message:
                self.update_status("Transfer", [42], "Fail", 7)
                return False
                
            # Test with amount that exceeds normal limits (should still work for own account transfer)
            large_amount = "1000000"  # 1,000,000 ETB

            self.send_ussd_input(1)
            message = self.get_ussd_message()

            
            self.send_ussd_input(self.amount)
            
            # Step 4: Enter remark
            message = self.get_ussd_message()
            # if "A space will be provided to upload remark" not in message:
            #     self.update_status("Transfer", [42], "Fail", 7)
            #     return False

            self.send_ussd_input(1)
            message = self.get_ussd_message()
                
            self.send_ussd_input("testremark")
            
            # Step 5: Confirm transfer
            message = self.get_ussd_message()
            # if "A confirmation notification will be displayed" not in message:
            #     self.update_status("Transfer", [42], "Fail", 7)
            #     return False
                
            self.send_ussd_input("1")  # Confirm
            
            # Verify success
            message = self.get_ussd_message()
            if "complete" in message.lower() or "debited" in message.lower():
                print("Transfer to own account successful", flush=True)
                self.update_status("Transfer", [42], "Pass", 7)
                return True
            else:
                self.update_status("Transfer", [42], "Fail", 7)
                return False
                
        except Exception as e:
            print(f"Error in transfer_to_own_account: {e}", flush=True)
            self.update_status("Transfer", [42], "Fail", 7)
            return False